var number = 0;
var display = document.getElementById("counter");
function likes(){
    number++;
    display.innerHTML = number;
}