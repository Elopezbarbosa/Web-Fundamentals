var likecount = [8,21,12];
var span = [
    document.querySelector("#like1"),
    document.querySelector("#like2"),
    document.querySelector("#like3")
];
function likes(id) {
    likecount [id]++;
    span[id].innerHTML =likecount [id];
}