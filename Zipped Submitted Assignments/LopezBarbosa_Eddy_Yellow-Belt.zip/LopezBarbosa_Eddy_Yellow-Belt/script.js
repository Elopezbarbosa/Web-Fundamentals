function popup() {
    alert ("This Game Is Supported On Linux!");
}
var count = 0;
var disp = document.getElementById("count")
function counter() {
    count++;
    disp.innerHTML = count;
}
function swapout() {
    document.getElementById("mainEvent").src = "images/pixel-ninjas-2.png";
}
function swapin() {
    document.getElementById("mainEvent").src = "images/stonepunk.png";
}
