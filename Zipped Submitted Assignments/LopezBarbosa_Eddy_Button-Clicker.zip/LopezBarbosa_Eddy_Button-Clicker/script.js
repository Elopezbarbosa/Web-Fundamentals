function popup() {
    alert("Ninja Was Liked!");
}
function bye(lol){
    lol.remove();
}
function login(element) {
    if (element.innerText == "Login") {
        element.innerText = "Logout";
    }
    else {
        element.innerText = "Login";
    }
}